import express from 'express';
import jwt from 'jsonwebtoken';
import Teacher from '../models/Teacher.js';

const router = express.Router();

// Register API
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if teacher already exists
    const existingTeacher = await Teacher.findOne({ email });
    if (existingTeacher) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Create a new teacher
    const teacher = new Teacher({ name, email, password });
    await teacher.save();

    // Generate JWT token
    const token = jwt.sign({ _id: teacher._id }, 'ababbabbabbabba', {
      expiresIn: '7d',
    });

    res.status(201).json({
      teacher: {
        _id: teacher._id,
        name: teacher.name,
        email: teacher.email,
      },
      token,
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Login API
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const teacher = await Teacher.findOne({ email });

    if (!teacher || !(await teacher.comparePassword(password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ _id: teacher._id },'ababbabbabbabba', {
      expiresIn: '7d',
    });

    res.json({
      teacher: {
        _id: teacher._id,
        name: teacher.name,
        email: teacher.email,
      },
      token,
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' },error);
  }
});

export default router;
