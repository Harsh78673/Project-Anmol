import express from 'express';
import { auth } from '../middleware/auth.js';
import Student from '../models/Student.js';
import Class from '../models/Class.js';

const router = express.Router();

router.post('/', auth, async (req, res) => {
  try {
    console.log(req.body)
    console.log(req.teacher)
    const classExists = await Class.findOne({
  
      _id: req.body.classId,
      teacherId: req.teacher._id,
    });

    if (!classExists) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const newStudent = new Student(req.body);
    await newStudent.save();
    res.status(201).json(newStudent);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/:classId', auth, async (req, res) => {
  try {
    const classExists = await Class.findOne({
      _id: req.params.classId,
      teacherId: req.teacher._id,
    });

    if (!classExists) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const students = await Student.find({ classId: req.params.classId });
    res.json(students);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;