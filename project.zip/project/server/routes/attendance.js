import express from 'express';
import { auth } from '../middleware/auth.js';
import Attendance from '../models/Attendance.js';
import Class from '../models/Class.js';
import Student from '../models/Student.js';

const router = express.Router();

router.post('/', auth, async (req, res) => {
  try {
    const { classId, studentId, date, status } = req.body;

    const classExists = await Class.findOne({
      _id: classId,
      teacherId: req.teacher._id,
    });

    if (!classExists) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const studentExists = await Student.findOne({
      _id: studentId,
      classId,
    });

    if (!studentExists) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const attendance = new Attendance({
      classId,
      studentId,
      date: new Date(date),
      status,
    });

    await attendance.save();
    res.status(201).json(attendance);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/:classId/:studentId', auth, async (req, res) => {
  try {
    const { classId, studentId } = req.params;

    const classExists = await Class.findOne({
      _id: classId,
      teacherId: req.teacher._id,
    });

    if (!classExists) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const studentExists = await Student.findOne({
      _id: studentId,
      classId,
    });

    if (!studentExists) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const attendance = await Attendance.find({
      classId,
      studentId,
    }).sort({ date: -1 });

    res.json(attendance);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;