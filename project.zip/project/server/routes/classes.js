import express from 'express';
import { auth } from '../middleware/auth.js';
import Class from '../models/Class.js';

const router = express.Router();

router.post('/', auth, async (req, res) => {
  try {
    const newClass = new Class({
      ...req.body,
      teacherId: req.teacher._id,
    });
    await newClass.save();
    res.status(201).json(newClass);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/', auth, async (req, res) => {
  try {
    const classes = await Class.find({ teacherId: req.teacher._id });
    res.json(classes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;