import jwt from 'jsonwebtoken';
import Teacher from '../models/Teacher.js';

export const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
   
    if (!token) {
      throw new Error();
    }

    const decoded = jwt.verify(token, 'ababbabbabbabba');
    const teacher = await Teacher.findById(decoded._id);
    
    if (!teacher) {
      throw new Error();
    }

    req.teacher = teacher;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Please authenticate.' });
  }
};