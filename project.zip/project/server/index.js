import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import morgan from 'morgan';

import authRoutes from './routes/auth.js';
import classesRoutes from './routes/classes.js';
import studentsRoutes from './routes/students.js';
import attendanceRoutes from './routes/attendance.js';

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

app.use(morgan('tiny'));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/attendance-system')
  .then(() => console.log('Connected to MongoDB'))
  .catch((error) => console.error('MongoDB connection error:', error));

// Routes

app.use('/auth', authRoutes);
app.use('/classes', classesRoutes);
app.use('/students', studentsRoutes);
app.use('/attendance', attendanceRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});