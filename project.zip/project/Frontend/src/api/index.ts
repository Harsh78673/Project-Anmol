import axios from 'axios';
import { useAuthStore } from '../store/auth';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000',
});

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const login = async (email: string, password: string) => {
  const response = await api.post('/auth/login', { email, password });
  return response.data;
};


export const registerUser = async (name: string, email: string, password: string) => {
  const response = await api.post('/auth/register', { name, email, password });
  return response.data;
};


export const createClass = async (data: {
  name: string;
  semester: string;
  startDate: string;
}) => {
  const response = await api.post('/classes', data);
  return response.data;
};

export const getClasses = async () => {
  const response = await api.get('/classes');
  return response.data;
};

export const addStudent = async (data: {

  name: string;
  rollNumber: string;
  classId: string;
}) => {
 
  const response = await api.post('/students', data);
  return response.data;
};

export const getStudents = async (classId: string) => {
  const response = await api.get(`/students/${classId}`);
  return response.data;
};

export const markAttendance = async (data: {
  studentId: string;
  classId: string;
  date: string;
  status: 'present' | 'absent';
}) => {
  const response = await api.post('/attendance', data);
  return response.data;
};

export const getAttendance = async (classId: string, studentId: string) => {
  const response = await api.get(`/attendance/${classId}/${studentId}`);
  return response.data;
};