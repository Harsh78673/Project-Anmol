import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Teacher } from '../types';

interface AuthState {
  teacher: Teacher | null;
  token: string | null;
  setAuth: (teacher: Teacher, token: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      teacher: null,
      token: null,
      setAuth: (teacher, token) => set({ teacher, token }),
      logout: () => set({ teacher: null, token: null }),
    }),
    {
      name: 'auth-storage',
    }
  )
);