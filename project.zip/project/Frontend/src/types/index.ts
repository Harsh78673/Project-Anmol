export interface Teacher {
  _id: string;
  name: string;
  email: string;
}

export interface Class {
  _id: string;
  name: string;
  teacherId: string;
  semester: string;
  startDate: string;
}

export interface Student {
  _id: string;
  name: string;
  rollNumber: string;
  classId: string;
}

export interface Attendance {
  _id: string;
  studentId: string;
  classId: string;
  date: string;
  status: 'present' | 'absent';
}

export interface LoginCredentials {
  email: string;
  password: string;
}