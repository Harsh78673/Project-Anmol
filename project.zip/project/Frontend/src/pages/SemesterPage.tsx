import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { format, parseISO } from 'date-fns';
import { Calendar, CheckCircle, XCircle } from 'lucide-react';
import { getAttendance, markAttendance } from '../api';
import type { Attendance } from '../types';

function SemesterPage() {
  const { classId, studentId } = useParams<{ classId: string; studentId: string }>();
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [isMarking, setIsMarking] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));

  useEffect(() => {
    console.log('Params:', { classId, studentId }); // Debugging
    if (classId && studentId) {
      loadAttendance();
    }
  }, [classId, studentId]);

  const loadAttendance = async () => {
    try {
      const data = await getAttendance(classId!, studentId!);
      setAttendance(data);
    } catch (error) {
      console.error('Failed to load attendance:', error);
    }
  };

  const handleMarkAttendance = async (status: 'present' | 'absent') => {
    try {
      setIsMarking(true);
      await markAttendance({
        studentId: studentId!,
        classId: classId!,
        date: selectedDate,
        status,
      });
      await loadAttendance();
    } catch (error) {
      console.error('Failed to mark attendance:', error);
    } finally {
      setIsMarking(false);
    }
  };

  const calculateAttendancePercentage = () => {
    if (attendance.length === 0) return 0;
    const presentDays = attendance.filter((a) => a.status === 'present').length;
    return Math.round((presentDays / attendance.length) * 100);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            <h1 className="text-2xl font-bold text-gray-900">Semester Attendance</h1>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <Calendar className="w-6 h-6 text-blue-600" />
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">Attendance Overview</h2>
                  <p className="text-sm text-gray-500">Total Classes: {attendance.length}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-blue-600">{calculateAttendancePercentage()}%</div>
                <div className="text-sm text-gray-500">Attendance Rate</div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Select Date</label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="flex space-x-4">
                <button
                  onClick={() => handleMarkAttendance('present')}
                  disabled={isMarking}
                  className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 disabled:opacity-50"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark Present
                </button>
                <button
                  onClick={() => handleMarkAttendance('absent')}
                  disabled={isMarking}
                  className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 disabled:opacity-50"
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Mark Absent
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Attendance History</h3>
            </div>
            <div className="border-t border-gray-200">
              <ul className="divide-y divide-gray-200">
                {attendance.map((record) => (
                  <li key={record.id} className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        {record.status === 'present' ? (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        ) : (
                          <XCircle className="w-5 h-5 text-red-500" />
                        )}
                        <span className="ml-2 text-sm text-gray-500">
                          {format(parseISO(record.date), 'MMMM d, yyyy')}
                        </span>
                      </div>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${record.status === 'present' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default SemesterPage;
