import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link } from 'react-router-dom';
import { useAuthStore } from './store/auth';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import ClassPage from './pages/ClassPage';
import SemesterPage from './pages/SemesterPage';

const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
  const teacher = useAuthStore((state) => state.teacher);
  return teacher ? <>{children}</> : <Navigate to="/auth" />;
};

const AuthPage = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
      <h1 className="text-2xl font-bold mb-4">Welcome to Attendance Manager</h1>
      <div className="space-x-4">
        <Link to="/login" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Login</Link>
        <Link to="/register" className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Register</Link>
      </div>
    </div>
  );
};

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/auth" replace />} />
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/class/:_id"
          element={
            <PrivateRoute>
              <ClassPage />
            </PrivateRoute>
          }
        />
        <Route
          path="/class/:classId/semester/:studentId"
          element={
            <PrivateRoute>
              <SemesterPage />
            </PrivateRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
